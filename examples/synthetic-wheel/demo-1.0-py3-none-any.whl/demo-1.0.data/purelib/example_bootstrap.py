def initialize():
    return None
