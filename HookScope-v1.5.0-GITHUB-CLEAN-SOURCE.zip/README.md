# HookScope

Version **1.5.0**. [Release audit](AUDIT.md) · [Changes](CHANGELOG.md).

Offline auditor for Python startup hooks. MITRE ATT&CK [T1546.018](https://attack.mitre.org/techniques/T1546/018/).

Analyzes mounted filesystem snapshots and Python wheels without importing or executing inspected code. Python 3.10+; standard library at runtime.

## Start here (no prior security knowledge required)

[Step-by-step beginner guide](docs/QUICKSTART.md) · [Termux instructions](docs/TERMUX.md)

After installing the package, type **`hookscope`** in a terminal. A numbered interactive menu appears. Choose **1** for a **read-only** scan of your own Termux Python directory; choose **2** to reopen the newest report. No file is quarantined or deleted by this menu scan.

```sh
hookscope                 # friendly numbered menu in a real terminal
hookscope start           # easy Termux scan; saves HTML + JSON and opens the HTML on-device
hookscope report          # open the latest saved HTML report
hookscope export          # copy latest HTML + JSON to Downloads after confirming
hookscope help            # plain-language guide
hookscope help scan       # conventional usage/options for the advanced scan command
hookscope doctor          # show detected paths without scanning
```

For other environments, specify the intended filesystem explicitly: `hookscope start --root /mnt/python-snapshot`. On noninteractive terminals/pipelines, bare `hookscope` prints a short getting-started guide rather than opening a blocking menu. Use `hookscope --help` or `hookscope scan --help` for standard argparse help. Existing advanced flags and JSON/SARIF outputs remain unchanged.

**Beginner output:** `start` puts timestamped `.html` and `.json` in `~/hookscope-reports/` (or `--report-dir`). HTML uses an offline, responsive layout with a plain-English guide; advanced diagnostic commands stay under an expandable section. A second scan after quarantine may report zero hooks because the first scan removed one from its startup directory. Zero matches do **not** mean the entire system is clean.

## Report preview

![HookScope example report — synthetic fixture](examples/reports/report-populated.png)

This screenshot shows a controlled synthetic fixture, not evidence of a compromised system. The local HTML report is responsive, works without JavaScript, and distinguishes an empty inventory from incomplete coverage.

## Install

```bash
python3 -m pip install .
hookscope --version
```

Alternatively, without installation:

```bash
python3 -m hookscope --help
```

Run from a **trusted analysis environment**, not from a Python interpreter inside a potentially compromised snapshot.

## Snapshot scan

```bash
hookscope scan \
  --root /mnt/readonly-image \
  --format json \
  --output ./findings.json
```

The scanner inventories `.pth` and `.start` files in `site-packages`/`dist-packages`, and `sitecustomize.py`/`usercustomize.py` throughout the snapshot. It inspects executable lines and entry points, attempts bounded local module resolution, and reports SHA-256 hashes and static code patterns, including directly imported modules and parent package `__init__.py` candidates. It identifies `pyvenv.cfg` where present but **does not execute the target interpreter to reconstruct its full `sys.path`**.

## Wheel inspection

```bash
hookscope wheel ./package-1.0-py3-none-any.whl \
  --python-version 3.15 \
  --format html \
  --output ./wheel-review.html
```

Wheel files are read directly as ZIP archives, **never installed or extracted**. HookScope inspects top-level and `.data/purelib` / `.data/platlib` startup candidates, parses direct imports, resolves local module candidates, and compares inspected startup artifacts with wheel `RECORD` hashes and size fields. This is **not a full-wheel integrity check**. `RECORD` is not a digital signature; the publisher can regenerate it.

## IOC matching

```bash
hookscope scan --root /mnt/readonly-image \
  --ioc-csv data/litellm-march-2026.csv \
  --ioc-csv data/litellm-october-2026.csv \
  --format sarif --output ./hookscope.sarif
```

IOC CSV columns: `Type,Value,Role,Campaign,SourceURL`. Only SHA-256 rows are used. Public incident indicators are source-attributed and separated by campaign; the project does not redistribute malicious samples.

## CI gates

```bash
hookscope wheel ./artifact.whl --fail-on high --strict --format json
```

Exit codes:

| Exit | Meaning |
|---|---|
| `0` | Scan completed without crossing the configured severity threshold |
| `2` | Invalid input, scan error, or `--strict` and incomplete scan |
| `3` | Finding at/above `--fail-on` severity |

`--fail-on` defaults to `never`. Executable `.pth` lines and `.start` entry points are **review candidates**, not malware verdicts. `--include-source-lines` is opt-in because startup lines can contain sensitive information.

## Output

The HTML report uses an evidence-oriented layout that remains informative when no artifacts are found. It distinguishes incomplete coverage from security findings, lists recognized site directories, and expands artifact-level reasoning, module candidates and hashes. Internal symlink aliases are displayed as traversal notes rather than malware indicators. Machine-readable JSON is still the most complete export, particularly for large scans.

`text`, `json`, `html`, and `sarif` (SARIF 2.1.0). Local HTML reports have no remote assets, JavaScript, analytics, or network dependencies. Reports may contain sensitive filesystem paths; share them accordingly.

Reproducible examples: `examples/synthetic-snapshot/`, `examples/synthetic-wheel/`, `examples/demo-report.json`, `examples/demo-report.html`, and `examples/demo-report.sarif`. The synthetic fixtures are not malicious samples.

## Tests

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q hookscope
bash tests/RELEASE-RUNTIME-VALIDATION.sh
```

The test suite includes a real benign Python startup integration test and covers parsing, Python-version behavior, module resolution, wheel integrity, invalid archives, traversal attempts, symlinks, byte limits, IOC matches, and CLI exit codes. Tests use temporary fixtures; there is no live adversary infrastructure.

## Scope

Read [Assumptions and boundaries](docs/ASSUMPTIONS.md), [Release audit](AUDIT.md), and [Security](SECURITY.md) before using HookScope for incident response. A filesystem snapshot does not establish what executed on a live endpoint. Sensor-independent execution evidence requires external telemetry.

Author: Mohammad Ali Nazlabadi. License: MIT (original tool code). Third-party research and indicators remain attributed to their publishers.

### Termux use

On an Android device with Termux, Python package directories are generally located beneath `$PREFIX/lib/pythonX.Y/site-packages`. The scanner does not require root access to analyze Termux-owned readable files. It cannot inspect private directories belonging to other Android apps without OS permissions.

```bash
hookscope scan --root "$PREFIX/lib" --format html --output "$HOME/hookscope.html"
hookscope scan --root "$PREFIX/lib" --strict --format json --output "$HOME/hookscope.json"
```

A report with zero artifacts does **not** mean the Android device is clean. A skipped linked directory may cause coverage to be marked incomplete; check the specific issue before treating it as a security risk.

## Interactive review and reversible remediation

**No files are changed by ordinary scans.** Explicit, user-approved quarantine is now available on POSIX systems. Files are moved to a private vault, not silently deleted; an audit receipt records original path and SHA-256. Review commands are printed in terminal text output and inside the offline HTML report. The user must confirm the exact artifact before changing it.

```bash
# Real executable, but harmless test hook in a random venv under a known lab directory
hookscope lab-create --root "$HOME/hookscope-lab"

# Scan and interactively decide whether to quarantine each medium/high candidate
hookscope scan --root "$HOME/hookscope-lab" --review

# Alternatively quarantine one exact artifact from the scan
hookscope quarantine --root "$HOME/hookscope-lab" --path 'lab-XXXXXXXX/env/lib/python3.13/site-packages/hookscope_lab.pth'

# Show receipts, restore a selected file or permanently purge a quarantined copy
hookscope quarantine-list
hookscope restore --id QUARANTINE_ID
hookscope purge --id QUARANTINE_ID
```

The example relative path above is illustrative; use the **exact path printed by your scan**. The randomly named lab stays under `$HOME/hookscope-lab`, never under the active Termux Python installation. The lab explicitly verifies its own harmless startup hook with the new venv Python; inspection of scanned code remains passive. For more detail and limitations, see [Safe lab and remediation](docs/REMEDIATION.md).

Termux users can run `hookscope scan --root "$PREFIX/lib" --review` for an interactive assessment of their Python library directory. Root access is not required for user-owned files; permissions still govern any quarantine. Avoid pressing `y` for legitimate installation hooks just because they have medium severity.


## What's new in v1.4

### Terminal identity

The interactive text-mode CLI displays a compact representation of the author's N monogram. This is deliberately limited to terminals, never JSON, SARIF, HTML, or redirected output. All functionality remains available without a banner.

```bash
hookscope banner                  # preview in Termux or another terminal
hookscope banner --ascii --no-color
hookscope scan --root "$PREFIX/lib" --no-banner
```

Terminals narrower than 42 columns get a compact label; `NO_COLOR=1` and `TERM=dumb` disable colors. No font, FIGlet, Rich, or third-party runtime library is needed.

### Compare two reports

A static snapshot can be clean today and change tomorrow. The `diff` command compares JSON reports by artifact path, SHA-256, startup status, severity, resolved-import fingerprints, IOC results, and relevant integrity metadata.

```bash
hookscope scan --root /mnt/readonly-snapshot --format json --output baseline.json
# After a deployment or at a different time:
hookscope scan --root /mnt/readonly-snapshot --format json --output current.json
hookscope diff --old baseline.json --new current.json --format text
hookscope diff --old baseline.json --new current.json --format json --fail-on-change
```

`diff --fail-on-change` exits `3` when the inventories differ. A changed report is an investigation lead, not a malware finding. Reports from different roots require explicit `--allow-different-root`. Incomplete scan coverage is flagged in the result. The comparison does not execute source code or access the original scanned filesystem.

### Verify quarantined files

```bash
hookscope quarantine-list
hookscope quarantine-verify
hookscope quarantine-verify --format json
```

This checks the receipt and SHA-256 of every quarantined item; restored and purged entries must no longer contain `artifact.data`. It returns exit `2` if any entry is corrupt or missing. It does not restore, purge, or execute files. Quarantine now rejects sources with multiple hard links, which cannot reliably be isolated by renaming one link.

**Important:** this is not antivirus, dynamic execution monitoring, automatic cleanup, or an assertion of compromise. The default workflow remains passive. Remediation changes files only after a separate explicit approval.

See [Termux guide](docs/TERMUX.md) and [release checklist](docs/RELEASE.md).
